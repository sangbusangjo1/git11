var express = require('express');
var app = express();
var bodyParser = require('body-Parser');
var login = 0;
var loginid;

var mysql = require('mysql');
var connection = mysql.createConnection({
	host: 'localhost',
	port: 3306,
	user: 'root',
	password: 'masickdang',
	database: 'masickdang'
});

connection.connect();
//make db connection

app.use(bodyParser());
app.set('views', './');
app.set('view engine','ejs');

app.get('/', function(req, res){
	if(login == 0){
		res.render('./index.ejs');
	}
	else{
		res.render('./index_login.ejs');
	}
});

app.get('/search_result', function(req, res){
	res.render('./search_result.ejs');
});

app.get('/search', function(req, res){
	res.render('./search.ejs');
})

app.get('/join', function(req, res){
	res.render('./join.ejs');
});

app.get('/login', function(req, res){
	res.render('./login.ejs');
})

app.get('/mypage', function(req, res){
	res.render('./mypage.ejs');
});

app.get('/shop_detail', function(req, res){
	if(login == 0){
		res.render('./shop_detail.ejs');
	}
	else{
		res.render('./shop_detail_login.ejs');
	}
});

app.get('/logout', function(req, res){
	login=0;
	console.log('logout');
	res.redirect('/');
})
//page setting

app.post('/join', function(req, res, next){
	var userid = req.body.userid;
	var password = req.body.password;
	var nickname = req.body.nickname;  
	var email = req.body.email;
	var gender = req.body.gender;
	var sql = 'INSERT INTO USERS VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
	connection.query(sql, [userid, nickname, password, gender, 0, 0, 0, email], function(err, result, fields){
		if(err){
			console.log(err);
		}
		else{
			res.redirect('/');
		}
	})
});
//join

app.post('/login', function(req,res){
	var id = req.body.uid;
	var pw = req.body.upw;

	connection.query("select count(*) cnt from users where UserId=? and Passwd=?", [id, pw], function(error, result){
		if(error){
			console.log("err", error);
		}
		else{
			if(result[0].cnt=='0'){
				console.log('login fail');
				res.redirect('/');
			}else{
				login = 1;
				loginid = id;
				console.log('login success');
				res.redirect('/');
			}
		}
	})
});
//login

app.post('/search', function(req, res){
	var hours = req.body.hours;
	var minutes = req.body.minutes;
	var man = req.body.man;
	var cheon = req.body.cheon;
	var menu = req.body.menu;
	if(hours==0 && minutes==0){
		if(man==0 && cheon==0){
			connection.query("select * from shop where category = ? and closingday <> (select date_format(now(), '%W'))", [menu], function(error, result){
				if(error){
					console.log("search error", error);
				}
				else{
					res.render("search_result", {shops: result});
					
				}
			})
		}
		else{
			connection.query("select * from shop where category = ? and (select avg(PRICE) from MENU where SHOPNO = shop.shopno and TYPE = '주메뉴') < (? * 10000 + ? * 1000) and closingday <> (select date_format(now(), '%W'))", [menu, man, cheon], function(error, result){
				if(error){
					console.log("search error", error);
				}
				else{
					res.render("search_result", {shops: result});
					
				}
			})
		}
	}
	else{
		if(man==0 && cheon==0){
			connection.query("select * from shop where category = ? and openTime <= ? and closeTime >=? and closingday <> (select date_format(now(), '%W'))", [menu, openTime, closeTime], function(error, result){
				if(error){
					console.log("search error", error);
				}
				else{
					res.render("search_result", {shops: result});
					
				}
			})
		}
		else{
			connection.query("select * from shop where category = ? and openTime <= ? and closeTime >=? and (select avg(PRICE) from MENU where SHOPNO = shop.shopno and TYPE = '주메뉴' and closingday <> (select date_format(now(), '%W'))", [menu, openTime, closeTime, man, cheon], function(error, result){
				if(error){
					console.log("search error", error);
				}
				else{
					res.render("search_result", {shops: result});
					
				}
			})
		}
	};
});

app.post('/search/detail', function(req, res){
})

app.listen(3000, function(){
	console.log('Connected 3000 port!');
	console.log('press Ctrl + C to exit.');
});